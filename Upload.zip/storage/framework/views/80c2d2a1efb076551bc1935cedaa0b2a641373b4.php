<!DOCTYPE html>
<html>
<style>
table, th, td {
  border:0.5px solid black;
}
</style>
<body>

<h2>Case Report</h2>

<table style="width:100%">
  <tr>
    <th>Id</th>
    <th>User id</th>
    <th>Case Number</th>
    <th>Case Fine</th>
    <th>Comments</th>
  </tr>
  <tr>
    <td><?php echo e($data['id']); ?></td>
    <td><?php echo e($data['userId']); ?></td>
    <td><?php echo e($data['caseId']); ?></td>
    <td><?php echo e($data['caseCode']); ?></td>
    <td><?php echo e($data['fineAmmount']); ?></td>
  </tr>
</table>



</body>
</html>

<?php /**PATH C:\Users\Public\Laravel\Laravel Breeze\laravel 9 Multi Auth\multyAuth\resources\views/download.blade.php ENDPATH**/ ?>