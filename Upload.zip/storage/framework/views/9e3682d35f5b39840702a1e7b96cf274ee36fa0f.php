
<?php $__env->startSection('adminUserView'); ?>

<!-- content @s -->
<div class="nk-content ">
    <div class="container-fluid">
        <div class="nk-content-inner">
            <div class="nk-content-body">
                <div class="components-preview wide-md mx-auto">
                    <div class="nk-block nk-block-lg">
                        <div class="card card-bordered">
                            <div class="card-inner">
                                <div class="row">
                                    <h2>Terms & Condition</h2>
                                    <hr>
                                    <form method="POST" action="<?php echo e(route('termsConditionPost')); ?>" >
                                        <?php echo csrf_field(); ?>
                                        <div class="row">
                                            <div class="form-group col-md-12 col-lg-12 col-xl-12 required">
                                                
                                                <textarea name="terms" id="terms" cols="70" rows="70" >
                                                <?php 
                                                    echo $termsCondition[0]->terms;
                                                ?>
                                                </textarea>
                                            </div>
                                           
                                            

                                        </div>
                                        <button class="btn btn-primary" type="submit">Save</button>
                                    </form>
                                </div>
                            </div>
                        </div>

                    </div><!-- card -->
                </div><!-- .nk-block -->
            </div><!-- .components-preview -->
        </div>
    </div>
</div>

<script>
        CKEDITOR.replace( 'terms' );
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('masterAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Public\Laravel\Laravel Breeze\laravel 9 Multi Auth\multyAuth\resources\views/adminTermsCondition.blade.php ENDPATH**/ ?>