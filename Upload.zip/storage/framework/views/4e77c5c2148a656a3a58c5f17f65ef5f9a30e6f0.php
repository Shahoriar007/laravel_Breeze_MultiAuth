
<?php $__env->startSection('profile'); ?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>


<style>
label.textcolor {
    color: black;
}
</style>

<body class="background">

    <div class="container">
        <div class="main-body">



            <br><br>

            <!--== Page Content Wrapper Start ==-->
            <div class="main-content p-tb-100">
                <div class="container container-xxl">
                    <div class="row">
                        <div class="col-lg-12">
                            <!-- My Account Page Start -->
                            <div class="myaccount-page-wrapper">
                                <!-- My Account Tab Menu Start -->
                                <div class="row">

                                    <?php echo $__env->make('sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <!--My Account Tab Menu End-->

                                    <!--My Account Tab Content Start-->
                                    <div class="col-lg-8 mt-5 mt-lg-0">
                                        <div class="tab-content" id="myaccountContent">
                                            <!-- Single Tab Content Start -->
                                            <div class="tab-pane fade show active" id="dashboad" role="tabpanel">
                                                <div class="myaccount-content">

                                                    <!--Content start  -->

                                                    <h3>Case Report</h3>



                                                    <?php if(Auth::guard('web')->user()->status == 1): ?>

                                                    <div class="title">Submit Cases</div>
                                                    <!-- forms start -->
                                                    <form method="POST"
                                                        action="<?php echo e(route('caseSubmit', Auth::guard('web')->user()->id)); ?>"
                                                        enctype="multipart/form-data">
                                                        <?php echo csrf_field(); ?>
                                                        <div class="form-group">
                                                            <!-- case image -->
                                                            <img id="showcasePhoto"
                                                                src="<?php echo e((!empty($caseDetails->casePhoto))? url('upload/case_images/' . $caseDetails->casePhoto):url('upload/no_image.jpg')); ?>"
                                                                width="100" height="100">

                                                        </div>

                                                        <div class="form-group">

                                                            <label class="textcolor" for="exampleInputEmail1">Case Number</label>

                                                            <input class="form-control" type="text" id="caseId"
                                                                name="caseId">
                                                            <?php $__errorArgs = ['caseId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="text-danger"><?php echo e($message); ?></span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>

                                                        <div class="form-group">
                                                            <label class="textcolor" for="exampleInputEmail1">Case Fine</label>

                                                            <input class="form-control" type="text" id="caseCode"
                                                                name="caseCode">
                                                            <?php $__errorArgs = ['caseCode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="text-danger"><?php echo e($message); ?></span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>

                                                        <div class="form-group">
                                                            <label class="textcolor" for="exampleInputEmail1">Comments(*if any) </label>

                                                            <input class="form-control" type="text" id="fineAmmount"
                                                                name="fineAmmount">
                                                        </div>

                                                        <div class="form-group">
                                                            <label class="textcolor" for="exampleInputEmail1">Case Photo</label>

                                                            <input class="form-control" type="file" id="casePhoto"
                                                                name="casePhoto">
                                                            <?php $__errorArgs = ['casePhoto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="text-danger"><?php echo e($message); ?></span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>



                                                        <button type="submit" class="btn btn-primary">Next></button>
                                                    </form>
                                                    <!-- forms end -->
                                                </div>

                                                <?php endif; ?>


                                                <!--Content end  -->

                                            </div>

                                        </div>
                                    </div>




                                </div>
                            </div>
                            <!-- My Account Tab Content End -->
                        </div>
                    </div>
                    <!-- My Account Page End -->
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript">
        $(document).ready(function(){
            $('#casePhoto').change(function(e){
                var reader = new FileReader();
                reader.onload = function(e){
                    $('#showcasePhoto').attr('src',e.target.result);
                }
                reader.readAsDataURL(e.target.files['0']);
            });
        });
    </script>




    <?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Public\Laravel\Laravel Breeze\laravel 9 Multi Auth\multyAuth\resources\views/caseReport.blade.php ENDPATH**/ ?>