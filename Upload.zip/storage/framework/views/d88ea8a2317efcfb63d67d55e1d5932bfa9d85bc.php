<div class="col-lg-4">
<div class="outer-box">
<h5 style="font-size: 14px; font-weight: bold; text-align: center;">পরিবরতন/যুক্ত করতে অপশনটিতে ক্লিক করুন</h5>

<div class="user-leftbar-details">
    <div>
        <?php if(Auth::user()->photo): ?>
            <img src="<?php echo e(asset(Auth::user()->photo)); ?>" class="img-responsive" alt="user">
        <?php else: ?>
            <img src="https://bootdey.com/img/Content/avatar/avatar7.png" class="img-responsive" alt="user">
        <?php endif; ?>
    </div>
    <div class="ml-2" style="font-size:14px">
        <h5 style="font-size:14px"><?php echo e(Auth::guard('web')->user()->name); ?></h5>
        <p>Reference Number: <span><?php echo e(Auth::guard('web')->user()->shareableRefcode); ?></span></p>
        <p>Position: <span><?php echo e(Auth::guard('web')->user()->designation); ?></span></p>
    </div>
</div>

    <div class="myaccount-tab-menu nav dropdown show inner-box" role="tablist">

        <a href="<?php echo e(route('main.home')); ?>">Home</a>

        <a href="<?php echo e(route('dashboard')); ?>" class="<?php echo e(Request::is('dashboard') ? 'active' : ''); ?>" >Dashboard</a>

        <a href="<?php echo e(route('caseReport')); ?>" class="<?php echo e(Request::is('dashboard/casereport') ? 'active' : ''); ?>" >Case Submit</a>

        <a href="<?php echo e(route('allCases', Auth::guard('web')->user()->id)); ?>" class="<?php echo e(Request::is('dashboard/allcases') ? 'active' : ''); ?>">All Cases</a>

        <!-- <a href="#case_report_list" data-toggle="tab">Case Report List</a> -->

        <a href="<?php echo e(route('profilePage')); ?>" class="<?php echo e(Request::is('dashboard/profile') ? 'active' : ''); ?>" >View Profile</a>

        <a href="<?php echo e(route('userProfileEdit', Auth::guard('web')->user()->id)); ?>">Edit Info</a>

        <a href="<?php echo e(route('userGeneralMsg', Auth::guard('web')->user()->id)); ?>" class="<?php echo e(Request::is('dashboard/support') ? 'active' : ''); ?>">Inbox</a>

        <a href="<?php echo e(route('userSupport', Auth::guard('web')->user()->id)); ?>" class="<?php echo e(Request::is('dashboard/support') ? 'active' : ''); ?>">Help Line</a>

        <a href="<?php echo e(route('generalCase', Auth::guard('web')->user()->id)); ?>" class="<?php echo e(Request::is('dashboard/generalCase') ? 'active' : ''); ?>">General Case</a>

        <a href="<?php echo e(route('userStatus', Auth::guard('web')->user()->id)); ?>"  class="<?php echo e(Request::is('dashboard/status') ? 'active' : ''); ?>">Present Status</a>

        <a href="<?php echo e(route('paymentHistory', Auth::guard('web')->user()->id)); ?>"  class="<?php echo e(Request::is('dashboard/paymentHistory') ? 'active' : ''); ?>">Payment History</a>

        <a href="#"  class="<?php echo e(Request::is('dashboard/paymentHistory') ? 'active' : ''); ?>">Renew</a>

        <form method="POST" action="<?php echo e(route('logout')); ?>" style="display: flex; justify-content: center; box-shadow: none;
    background: transparent;
    padding: 14px;">
                    <?php echo csrf_field(); ?>

                    <button type="submit" class="btn btn-danger text-center">Logout</button>
                </form>

    </div>
    
    </div>
    
</div><?php /**PATH C:\Users\Public\Laravel\Laravel Breeze\laravel 9 Multi Auth\multyAuth\resources\views/sidebar.blade.php ENDPATH**/ ?>