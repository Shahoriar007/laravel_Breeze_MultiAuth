
<?php $__env->startSection('adminCaseView'); ?>



<style>
div#example_info {
    font-size: medium;
    padding-top: 30px;
}

div#example_paginate {
    padding-top: 30px;
}

div.dataTables_wrapper div.dataTables_filter input {
    display: inline-block;
    font-size: 15px !important;
    padding: 10px !important;
}

div.dataTables_wrapper div.dataTables_length select {
    width: auto;
    display: inline-block;
    font-size: 15px !important;
    padding: 10px;
}

.nk-menu-text {
    flex-grow: 1;
    display: inline-block;
    white-space: nowrap;
    padding: 8px !important;
}
</style>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css"
    integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">



</head>

<body>

    <div>
        <a href="<?php echo e(route('admin.dashboard')); ?>"> Dashboard</a>
    </div>
    <br>
    <br>

    <h2 class="text-center">Completed Case Table</h2>

    <div style="overflow-x:auto;">
        <table id="example" class="display" style="width:100%">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>User Name</th>
                    <th>Case Number</th>
                    <th>Case Fine</th>
                    <th>Comments</th>
                    <th>Case Status</th>
                    <th>Paid With</th>
                    <th>Transaction Id</th>

                    <th>Action</th>
                </tr>
            </thead>
            <tbody>

                <?php $__currentLoopData = $completedCase; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->id); ?></td>
                    
                    <?php
                        $userName = \App\Models\User::findOrFail($item->userId);
                    ?>

                    <td><?php echo e($userName->name); ?></td>

                    <td><?php echo e($item->caseId); ?></td>
                    <td><?php echo e($item->caseCode); ?></td>
                    <td><?php echo e($item->fineAmmount); ?></td>
                    <td><?php echo e($item->caseStatus); ?></td>
                    <td><?php echo e($item->paidWith); ?></td>
                    <td><?php echo e($item->trId); ?></td>


                    <td>
                        <a href="<?php echo e(url('admin/viewcases')); ?>/<?php echo e($item->id); ?>">
                            <button type="button" class="btn btn-primary">Details</button>
                        </a>
                        <a href="<?php echo e(url('admin/caseDelete')); ?>/<?php echo e($item->id); ?>" id="delete">
                            <button type="button" class="btn btn-danger">Delete</button>
                        </a>
                    </td>

                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
            <tfoot>
                <tr>
                    <th>Id</th>
                    <th>User Name</th>
                    <th>Case Number</th>
                    <th>Case Fine</th>
                    <th>Comments</th>
                    <th>Case Status</th>
                    <th>Paid With</th>
                    <th>Transaction Id</th>

                    <th>Action</th>

                </tr>
            </tfoot>

        </table>
    </div>



    <script src="https://code.jquery.com/jquery-3.6.2.min.js"
        integrity="sha256-2krYZKh//PcchRtd+H+VyyQoZ/e3EcrkxhM8ycwASPA=" crossorigin="anonymous"></script>

    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.js">
    </script>

    <script type="text/Javascript">

        // $(document).ready( function () {
    // $('#myTable').DataTable();
    // });

    $(document).ready(function () {
        
    // Setup - add a text input to each footer cell
    $('#example thead tr')
        .clone(true)
        .addClass('filters')
        .appendTo('#example thead');
 
    var table = $('#example').DataTable({
        orderCellsTop: true,
        fixedHeader: true,
        initComplete: function () {
            var api = this.api();
 
            // For each column
            api
                .columns()
                .eq(0)
                .each(function (colIdx) {
                    // Set the header cell to contain the input element
                    var cell = $('.filters th').eq(
                        $(api.column(colIdx).header()).index()
                    );
                    var title = $(cell).text();
                    $(cell).html('<input type="text" placeholder="' + title + '" />');
 
                    // On every keypress in this input
                    $(
                        'input',
                        $('.filters th').eq($(api.column(colIdx).header()).index())
                    )
                        .off('keyup change')
                        .on('change', function (e) {
                            // Get the search value
                            $(this).attr('title', $(this).val());
                            var regexr = '({search})'; //$(this).parents('th').find('select').val();
 
                            var cursorPosition = this.selectionStart;
                            // Search the column for that value
                            api
                                .column(colIdx)
                                .search(
                                    this.value != ''
                                        ? regexr.replace('{search}', '(((' + this.value + ')))')
                                        : '',
                                    this.value != '',
                                    this.value == ''
                                )
                                .draw();
                        })
                        .on('keyup', function (e) {
                            e.stopPropagation();
 
                            $(this).trigger('change');
                            $(this)
                                .focus()[0]
                                .setSelectionRange(cursorPosition, cursorPosition);
                        });
                });
        },
    });
});
   
</script>


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('masterAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Public\Laravel\Laravel Breeze\laravel 9 Multi Auth\multyAuth\resources\views/completedCase.blade.php ENDPATH**/ ?>