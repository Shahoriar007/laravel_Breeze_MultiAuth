
<?php $__env->startSection('profile'); ?>


<body class="background">

    <div class="container">
        <div class="main-body">

            <br><br>

            <!--== Page Content Wrapper Start ==-->
            <div class="main-content p-tb-100">
                <div class="container container-xxl">
                    <div class="row">
                        <div class="col-lg-12">
                            <!-- My Account Page Start -->
                            <div class="myaccount-page-wrapper">
                                <!-- My Account Tab Menu Start -->
                                <div class="row">

                                    <?php echo $__env->make('sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <!--My Account Tab Menu End-->

                                    <!--My Account Tab Content Start-->

                                    <div class="col-lg-8">
                                    <table class="table">
                                        <thead class="thead-dark">
                                            <tr>
                                                <th scope="col">ID</th>
                                                <th scope="col">Case Number</th>
                                                <th scope="col">Case Fine</th>
                                                <th scope="col">Status</th>
                                                <th scope="col">Date & Time</th>
                                                <th scope="col">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                        <?php $__currentLoopData = $usersAllCases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $caseList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($caseList->id); ?></td>
                                                <td><?php echo e($caseList->caseId); ?></td>
                                                <td><?php echo e($caseList->caseCode); ?></td>
                                                <td><?php echo e($caseList->caseStatus); ?></td>
                                                <td><?php echo e($caseList->created_at); ?></td>

                                                <td>
                                                    <a href="<?php echo e(route('allCasesDetails',$caseList->id)); ?>">
                                                        <button type="button" class="btn btn-primary">Details</button>
                                                    </a>
                                                </td>

                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </tbody>
                                    </table>
                                    </div>

                                    <!-- My Account Tab Content End -->
                                </div>
                            </div>
                            <!-- My Account Page End -->
                        </div>
                    </div>
                </div>
            </div>

            <?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Public\Laravel\Laravel Breeze\laravel 9 Multi Auth\multyAuth\resources\views/allSubmittedCase.blade.php ENDPATH**/ ?>