
<?php $__env->startSection('adminUserView'); ?>

<!-- content @s -->
<div class="nk-content ">
    <div class="container-fluid">
        <div class="nk-content-inner">
            <div class="nk-content-body">
                <div class="components-preview wide-md mx-auto">
                    <div class="nk-block nk-block-lg">
                        <div class="card card-bordered">
                            <div class="card-inner">
                                <div class="row">
                                    <h2>Tranning Branch</h2>
                                    <hr>
                                    <form method="POST" action="<?php echo e(route('addTranningBranch')); ?>" >
                                        <?php echo csrf_field(); ?>
                                        <div class="row">
                                            <div class="form-group col-md-6 col-lg-6 col-xl-6 required">
                                                <label for="input-pass">Name <span class="required-f">*</span></label>
                                                <input name="name" id="name" type="text" required>
                                            </div>

                                            <div class="form-group col-md-6 col-lg-6 col-xl-6 required">
                                                <label for="input-pass">Address <span class="required-f">*</span></label>
                                                <input name="address" id="address" type="text" required>
                                            </div>

                                            <div class="form-group col-md-6 col-lg-6 col-xl-6 required">
                                                <label for="input-pass">Phone <span class="required-f">*</span></label>
                                                <input name="phone" id="phone" type="text" required>
                                            </div>
                                           
                                

                                        </div>
                                        <button class="btn btn-primary" type="submit">Save</button>
                                    </form>
                                </div>
                            </div>
                        </div>

                        <div class="card card-bordered">
                            <div class="card-inner">

                                <h1>List</h1>

                                <div class="card-head">
                                    <h5 class="card-title">Tranning Branch List</h5>
                                </div>
                                <div>
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th class="pro-id">Id</th>
                                                <th class="pro-text">Name</th>
                                                <th class="pro-text">Address</th>
                                                <th class="pro-text">Phone</th>
                                                <th class="pro-text">Action</th>
                                               
                                            </tr>
                                        </thead>
                                        <tbody>

                                        <?php if(!empty($teanningBranch)): ?>
                                           
                                        <?php $__currentLoopData = $teanningBranch; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       
                                            <tr>
                                                <td><?php echo e($data->id); ?></td>
                                                <td><?php echo e($data->name); ?></td>
                                                <td><?php echo e($data->address); ?></td>
                                                <td><?php echo e($data->phone); ?></td>
                                               
                                                <td>
                                                    <a href="<?php echo e(route('deleteTranningBranch', $data->id)); ?>" class="btn btn-danger">Delete</a>
                                                </td>
                                                
                                            </tr>

                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <?php endif; ?>
                                            

                                </div>
                            
                            </div>
                        </div>
                    </div><!-- card -->
                </div><!-- .nk-block -->
            </div><!-- .components-preview -->
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('masterAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Public\Laravel\Laravel Breeze\laravel 9 Multi Auth\multyAuth\resources\views/adminTranningBranch.blade.php ENDPATH**/ ?>