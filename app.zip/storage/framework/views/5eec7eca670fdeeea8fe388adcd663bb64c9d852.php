
<?php $__env->startSection('dashboard'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>




<body class="background">

    <nav class="header-wrap animated navbar navbar-expand-md navbar-dark bg-dark">
        <a class="navbar-brand logo" href="index.html"><img src="<?php echo e(asset('img/logo1.png')); ?>" alt=""></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav m-auto">
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('main.home')); ?>">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('main.home')); ?>#services">Services</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('main.home')); ?>#about">About</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('main.home')); ?>#contact">Contact</a>
                </li>

                <?php if(Route::has('login')): ?>

                <?php if(auth()->guard()->check()): ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
                </li>
                <?php else: ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('login')); ?>">Sign In</a>
                </li>
                <?php if(Route::has('register')): ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('register')); ?>">Register</a>
                </li>
                <?php endif; ?>
                <?php endif; ?>

                <?php endif; ?>

                <?php if(Route::has('dashboard')): ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('profilePage')); ?>">Profile Details</a>
                </li>

                <form method="POST" action="<?php echo e(route('logout')); ?>" style="display: flex; justify-content: center;">
                    <?php echo csrf_field(); ?>

                    <button type="submit" class="btn btn-danger text-center">Logout</button>
                </form>
                <?php endif; ?>

            </ul>
        </div>
    </nav>

    <section class="registration">
        <div class="backtopage"><a href="<?php echo e(route('main.home')); ?>"><i class="fas fa-chevron-left"></i>Go to homepage</a>
        </div>



        <!--== Page Content Wrapper Start ==-->
        <div class="main-content p-tb-100">
            <div class="container container-xxl">
                <div class="row">
                    <div class="col-lg-12">
                        <!-- My Account Page Start -->
                        <div class="myaccount-page-wrapper">
                            <!-- My Account Tab Menu Start -->
                            <div class="row">
                                <div class="col-lg-4">

                                <h5 style="font-size: 14px; font-weight: bold; text-align: center;">পরিবরতন/যুক্ত করতে অপশনটিতে ক্লিক করুন</h5>

                                <div class="user-leftbar-details">
                                    <div>
                                        <img src="<?php echo e(asset('userFrontend/img/user-pik.jpg')); ?>" class="img-responsive" alt="user">
                                    </div>
                                    <div class="ml-2">
                                        <h5>Adv. Sharifuzzaman</h5>
                                        <p>Reference Number: <span>01910512921</span></p>
                                        <p>Position: <span>User or Admin</span></p>
                                    </div>
                                </div>

                                    <div class="myaccount-tab-menu nav" role="tablist">

                                        <a href="#dashboad" class="active" data-toggle="tab">
                                            Dashboard</a>

                                        <a href="#case_report" data-toggle="tab">Case Report</a>

                                        <!-- <a href="#case_report_list" data-toggle="tab">Case Report List</a> -->

                                        <a href="<?php echo e(route('profilePage')); ?>">Profile</a>


                                    </div>
                                </div>
                                <!--My Account Tab Menu End-->

                                <!--My Account Tab Content Start-->
                                <div class="col-lg-8 mt-5 mt-lg-0">
                                    <div class="tab-content" id="myaccountContent">
                                        <!-- Single Tab Content Start -->
                                        <div class="tab-pane fade show active" id="dashboad" role="tabpanel">
                                            <div class="myaccount-content">
                                                <h3>Dashboard</h3>

                                                <div class="row">
                                                    <div class="col-md-8 .reg-box mx-auto">


                                                        <?php if(Auth::guard('web')->user()->status == 1): ?>


                                                        <h4 class="fw-bold text-center">Your account is approved.</h4>
                                                        <div class="backtopage">
                                                            <h4> You can share this Reference Number - <?php echo e(Auth::guard('web')->user()->shareableRefcode); ?> </h4>
                                                        </div>



                                                        <?php else: ?>

                                                        <div class="title">Registration Done!</div>
                                                        <div class="backtopage">
                                                            <h4> Hello! <?php echo e(Auth::guard('web')->user()->name); ?></h4>
                                                        </div>
                                                        <h4 class="fw-bold text-center">Soon your request will be
                                                            approved.</h4>
                                                        <?php endif; ?>

                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                        <!-- Single Tab Content End -->

                                        <!-- Single Tab Content Start -->
                                        <div class="tab-pane fade" id="case_report" role="tabpanel">
                                            <div class="myaccount-content">
                                                <h3>Case Report</h3>



                                                <?php if(Auth::guard('web')->user()->status == 1): ?>

                                                <div class="title">Submit Cases</div>
                                                <!-- forms start -->
                                                <form method="POST"
                                                    action="<?php echo e(route('caseSubmit', Auth::guard('web')->user()->id)); ?>"
                                                    enctype="multipart/form-data">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="form-group">
                                                        <!-- case image -->
                                                        <img id="showcasePhoto"
                                                            src="<?php echo e((!empty($caseDetails->casePhoto))? url('upload/case_images/' . $caseDetails->casePhoto):url('upload/no_image.jpg')); ?>"
                                                            width="100" height="100">

                                                    </div>

                                                    <div class="form-group">

                                                        <label for="exampleInputEmail1">Case Number</label>

                                                        <input class="form-control" type="text" id="caseId"
                                                            name="caseId">
                                                        <?php $__errorArgs = ['caseId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="text-danger"><?php echo e($message); ?></span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>

                                                    <div class="form-group">
                                                        <label for="exampleInputEmail1">Case Fine</label>

                                                        <input class="form-control" type="text" id="caseCode"
                                                            name="caseCode">
                                                        <?php $__errorArgs = ['caseCode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="text-danger"><?php echo e($message); ?></span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>

                                                    <div class="form-group">
                                                        <label for="exampleInputEmail1">Comments(*if any) </label>

                                                        <input class="form-control" type="text" id="fineAmmount"
                                                            name="fineAmmount">
                                                    </div>

                                                    <div class="form-group">
                                                        <label for="exampleInputEmail1">Case Photo</label>

                                                        <input class="form-control" type="file" id="casePhoto"
                                                            name="casePhoto">
                                                        <?php $__errorArgs = ['casePhoto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="text-danger"><?php echo e($message); ?></span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>



                                                    <button type="submit" class="btn btn-primary">Submit</button>
                                                </form>
                                                <!-- forms end -->
                                            </div>

                                            <?php endif; ?>

                                        </div>
                                    </div>
                                    <!-- Single Tab Content End -->



                                    <!-- Single Tab Content Start -->
                                    <!-- <div class="tab-pane fade" id="case_report_list" role="tabpanel">
                                    <div class="myaccount-content">
                                        <h3>Case Report List</h3>

                                       
                                    </div>
                                </div> -->
                                    <!-- Single Tab Content End -->

                                    <!-- Single Tab Content Start -->
                                    <!-- <div class="tab-pane fade" id="profile" role="tabpanel">
                                    <div class="myaccount-content">
                                        <h3>Profile</h3>
                                        
                                    </div>
                                </div> -->
                                    <!-- Single Tab Content End -->
                                </div>
                            </div>
                            <!-- My Account Tab Content End -->
                        </div>
                    </div>
                    <!-- My Account Page End -->
                </div>
            </div>
        </div>
        </div>
        <!--== Page Content Wrapper End ==-->


    </section>


</body>

<!-- <script type="text/javascript">
    $(document).ready(function () {
        
        $('#casePhoto').change(function (e) {

            var reader = new FileReader();
            reader.onload = function (e) {
                $('#showcasePhoto').attr('src', e.target.result);
            }
            reader.readAsDataURL(e.target.files['0']);
        });
    });
</script> -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Public\Laravel\Laravel Breeze\laravel 9 Multi Auth\multyAuth\resources\views/dashboard.blade.php ENDPATH**/ ?>