<body class="background">
<section class="registration">
        <div class="backtopage"><a href="<?php echo e(route('main.home')); ?>"><i class="fas fa-chevron-left"></i>Go to homepage</a></div>
        
        <div class="title">Registration Done!</div>

        <div class="backtopage"> <h4> hello! <?php echo e(Auth::guard('web')->user()->name); ?> </h4></div>


        <div class="container">
            <div class="row">
                <div class="col-md-8 .reg-box mx-auto">
                    

                    <?php if(Auth::guard('web')->user()->status == 1): ?>
                    <h4 class="fw-bold text-center">Your account is approved. More function will come soon!</h4>
                    <?php else: ?>
                    <h4 class="fw-bold text-center">Soon your request will be approved.</h4>
                    <?php endif; ?>

                    <form method="POST" action="<?php echo e(route('logout')); ?>"   style="display: flex; justify-content: center;">
                            <?php echo csrf_field(); ?>      
                            
                            <button type="submit" class="btn btn-danger text-center">Logout</button>
                    </form>
                    
                     
                </div>
            </div>
        </div>
    </section>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Public\Laravel\Laravel Breeze\laravel 9 Multi Auth\multyAuth\resources\views/dashboard.blade.php ENDPATH**/ ?>