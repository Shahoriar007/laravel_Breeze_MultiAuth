
<?php $__env->startSection('adminCaseView'); ?>



<style>
/* table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
} */
table {
  border-collapse: collapse;
  border-spacing: 0;
  width: 100%;
  border: 1px solid #ddd;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}

th, td {
  text-align: left;
  padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}
</style>



</head>
<body>

<div>
    <a href="<?php echo e(route('admin.dashboard')); ?>"> Dashboard</a>
</div>
<br>
<br>
<br>
<br>
<br>
<h2>Case Table</h2>

<div style="overflow-x:auto;">
<table>
  <tr>
    <th>ID</th>
    <th>User ID</th>
    <th>Case ID</th>
    <th>Case code</th>
    <th>fine ammount</th>
    
    <th>Action</th>
  </tr>

<?php $__currentLoopData = $cases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($item->id); ?></td>
        <td><?php echo e($item->userId); ?></td>
        <td><?php echo e($item->caseId); ?></td>
        <td><?php echo e($item->caseCode); ?></td>
        <td><?php echo e($item->fineAmmount); ?></td>
        

        <td>
            <a href="<?php echo e(url('admin/viewcases')); ?>/<?php echo e($item->id); ?>">
                <button type="button" class="btn btn-primary">Details</button>
            </a>
        </td>
        
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>

<!-- Pagination -->
<!-- <br>
<br>
<div class="row justify-content-md-center">
  <div class="col-md-auto">
  <?php echo e($cases->links()); ?>

  </div> 
</div>
<br>
<br> -->

</div>


  
<script
  src="https://code.jquery.com/jquery-3.6.2.min.js"
  integrity="sha256-2krYZKh//PcchRtd+H+VyyQoZ/e3EcrkxhM8ycwASPA="
  crossorigin="anonymous"></script>

  <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.js"></script>

 <script type="text/Javascript">

    $(document).ready( function () {
    $('#myTable').DataTable();
    });
   
</script>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('masterAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Public\Laravel\Laravel Breeze\laravel 9 Multi Auth\multyAuth\resources\views/cases_view.blade.php ENDPATH**/ ?>