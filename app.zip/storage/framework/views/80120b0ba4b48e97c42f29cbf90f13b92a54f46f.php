
<?php $__env->startSection('adminCaseView'); ?>




<style>
/* table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
} */
table {
  border-collapse: collapse;
  border-spacing: 0;
  width: 100%;
  border: 1px solid #ddd;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}

th, td {
  text-align: left;
  padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}
</style>
</head>
<body>

<div>
    <a href="<?php echo e(route('admin.dashboard')); ?>"> Dashboard</a>
</div>

<h2>HTML Table</h2>

<div style="overflow-x:auto;">
<table>
  <tr>
    <th>ID</th>
    <th>User ID</th>
    <th>Case ID</th>
    <th>Case code</th>
    <th>fine ammount</th>
    
    <th>Action</th>
  </tr>

<?php $__currentLoopData = $cases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($item->id); ?></td>
        <td><?php echo e($item->userId); ?></td>
        <td><?php echo e($item->caseId); ?></td>
        <td><?php echo e($item->caseCode); ?></td>
        <td><?php echo e($item->fineAmmount); ?></td>
        

        <td>
            <a href="<?php echo e(url('admin/viewcases')); ?>/<?php echo e($item->id); ?>">
                <button type="button" class="btn btn-primary">Details</button>
            </a>
        </td>
        
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>

<!-- Pagination -->
<br>
<br>
<div class="row justify-content-md-center">
  <div class="col-md-auto">
  <?php echo e($cases->links()); ?>

  </div> 
</div>
<br>
<br>

</div>


      

<?php $__env->stopSection(); ?>



<?php echo $__env->make('masterAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Public\Laravel\Laravel Breeze\laravel 9 Multi Auth\multyAuth\resources\views/cases_view.blade.php ENDPATH**/ ?>