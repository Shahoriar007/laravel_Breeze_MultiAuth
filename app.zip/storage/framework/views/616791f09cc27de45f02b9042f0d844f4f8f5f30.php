
                <!----------------------------------------------- Body Part End ---------------------------------------------->
                


               
                </div>
            <!-- wrap @e -->
        </div>
        <!-- main @e -->
    </div>
    <!-- app-root @e -->

  

  
</body><?php /**PATH C:\Users\Public\Laravel\Laravel Breeze\laravel 9 Multi Auth\multyAuth\resources\views/user/userFooter.blade.php ENDPATH**/ ?>