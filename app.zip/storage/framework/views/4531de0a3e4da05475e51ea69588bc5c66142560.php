<html>
    <head>

    <!-- Css datatable -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

<!-- Data Tables -->
<link rel="stylesheet"  href="//cdn.datatables.net/1.13.1/css/jquery.dataTables.min.css"/>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js"></script>

    </head>

    <body>
        <h2>check table</h2>

        <table id="" class="display">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">First</th>
      <th scope="col">Last</th>
      <th scope="col">Handle</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>Mark</td>
      <td>Otto</td>
      <td>@mdo</td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Jacob</td>
      <td>Thornton</td>
      <td>@fat</td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Larry</td>
      <td>the Bird</td>
      <td>@twitter</td>
    </tr>
  </tbody>
</table>

<button id="myTable" type="button" class="btn btn-primary">Primary</button>



        <!-- Data tables -->
    <script type="text/javascript" src="//cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.2.min.js" integrity="sha256-2krYZKh//PcchRtd+H+VyyQoZ/e3EcrkxhM8ycwASPA=" crossorigin="anonymous"></script>

    <script type="text/javascript">

    // $(document).ready( function () {
    //     //$("#myTable").DataTable();

    //     console.log('hi');

    // } );

//     jQuery.noConflict()(function () { // this was missing for me
//     $(document).ready(function() { 

//        //$("#myTable").DataTable();

//        console.log('hi');

//     });
// });

    </script>

<script type="text/javascript">
        $("#myTable").click(function(e) {
            e.preventDefault();
console.log('I love you');
});

</script>

    </body>
</html><?php /**PATH C:\Users\Public\Laravel\Laravel Breeze\laravel 9 Multi Auth\multyAuth\resources\views/checkkkkkkk.blade.php ENDPATH**/ ?>