<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nirapod Chalok Chai</title>

    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('userFrontend/img/favicon/apple-touch-icon.png')); ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('userFrontend/img/favicon/favicon-32x32.png')); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('userFrontend/img/favicon/favicon-16x16.png')); ?>">
    <link rel="manifest" href="img/favicon/site.webmanifest">


    <link rel="stylesheet" href="<?php echo e(asset('userFrontend/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('userFrontend/css/nice-select.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('userFrontend/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('userFrontend/css/asd.css')); ?>">

    <!-- <link rel="stylesheet" href="assets/css/style.css"> -->
    <link rel="stylesheet" href="<?php echo e(asset('userFrontend/assets/css/asd.css')); ?>">
    
    <link rel="stylesheet" type="text/css" 
     href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
</head>



<?php echo $__env->yieldContent('home'); ?>
<?php echo $__env->yieldContent('login'); ?>
<?php echo $__env->yieldContent('register'); ?>
<?php echo $__env->yieldContent('registerTrn'); ?>

<?php echo $__env->yieldContent('registeredit'); ?>
<?php echo $__env->yieldContent('dashboard'); ?>
<?php echo $__env->yieldContent('profile'); ?>



    <script src="<?php echo e(asset('userFrontend/js/jquery-3.6.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('userFrontend/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('userFrontend/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('userFrontend/js/jquery.nice-select.js')); ?>"></script>
    <script src="https://kit.fontawesome.com/30c7cd8c6d.js" crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('userFrontend/js/main.js')); ?>"></script>

    <!---=====jquery====-->
    <script src="<?php echo e(asset('userFrontend/assets/js/jquery-3.6.0.min.js')); ?>"></script>
    <!--=====popper js=====-->
  
    <script src="<?php echo e(asset('userFrontend/assets/js/bootstrap.min.js')); ?>"></script>

    <script>
        (document).ready(function() {
            $('select').niceSelect();
        });
    </script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"> </script>

<script>
    <?php if(Session::has('message')): ?>
    var type = "<?php echo e(Session::get('alert-type','info')); ?>"
    switch(type){
        case 'info':
            toastr.info(" <?php echo e(Session::get('message')); ?> ");
        break;
        case 'success':
            toastr.success(" <?php echo e(Session::get('message')); ?> ");
        break;
        case 'warning':
            toastr.warning(" <?php echo e(Session::get('message')); ?> ");
        break;
        case 'error':
            toastr.error(" <?php echo e(Session::get('message')); ?> ");
        break;
    }
    <?php endif; ?>
</script>



</body>

</html><?php /**PATH C:\Users\Public\Laravel\Laravel Breeze\laravel 9 Multi Auth\multyAuth\resources\views/master.blade.php ENDPATH**/ ?>