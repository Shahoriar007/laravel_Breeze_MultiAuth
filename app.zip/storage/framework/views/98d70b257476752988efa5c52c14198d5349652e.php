<?php $__env->startSection('login'); ?>

<body class="background">
    <section class="registration">
    <div class="backtopage"><a href="<?php echo e(route('main.home')); ?>"><i class="fas fa-chevron-left"></i>Go to homepage</a></div>
        <div class="title">Sign Here</div>
        <div class="container">
            <div class="row">
                <div class="col-md-4 .reg-box mx-auto">

                <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="user__details">
                            <div class="row">

                                <div class="input__box col-md-12">
                                    <span class="details">Phone Number</span>
                                    <input id="login" type="text" name="login" placeholder="01353456789" >
                                    <?php $__errorArgs = ['login'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?>(Please input phone number) </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="input__box col-md-12">
                                    <span class="details">Password</span>
                                    <input id="password" type="password" name="password" placeholder="********" >
                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                            </div>
                        </div>
                        <div class="button text-center">
                            <input type="submit" class="fire mb-2">
                            <div>Doesn't have account? <a href="<?php echo e(route('register')); ?>" style="color: #fbc72a;">Registration</a>
                            </div>
                        </div>

                  
                    </form>
                    
                </div>
            </div>
        </div>
    </section>
            
<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Public\Laravel\Laravel Breeze\laravel 9 Multi Auth\multyAuth\resources\views/auth/login.blade.php ENDPATH**/ ?>