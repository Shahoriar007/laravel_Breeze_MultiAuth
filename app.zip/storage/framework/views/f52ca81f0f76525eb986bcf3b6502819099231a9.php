<!DOCTYPE html>
<html lang="zxx" class="js">

<head>
    <base href="./">
    <meta charset="utf-8">
    <meta name="author" content="Softnio">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="A powerful and conceptual apps base dashboard template that especially build for developers and programmers.">
    <!-- Fav Icon  -->
    <link rel="shortcut icon" href="<?php echo e(asset('adminFrontend/images/favicon.png')); ?>">
    <!-- Page Title  -->
    <title>DashLite Template</title>
    <!-- StyleSheets  -->
    <link rel="stylesheet" href="<?php echo e(asset('adminFrontend/assets/css/dashlite.css?ver=3.1.1')); ?>">
    <link id="skin-default" rel="stylesheet" href="<?php echo e(asset('adminFrontend/assets/css/theme.css?ver=3.1.1')); ?>">

        
    <link rel="stylesheet" type="text/css" 
     href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
</head>

<?php echo $__env->make('admin.adminNavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('adminDashboard'); ?>
    <?php echo $__env->yieldContent('adminCaseView'); ?>
    <?php echo $__env->yieldContent('adminUserView'); ?>
    

    <?php echo $__env->yieldContent('adminViewcasesDetais'); ?>
    <?php echo $__env->yieldContent('adminUserDetaisView'); ?>

<?php echo $__env->make('admin.adminFooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!-- JavaScript -->
    <script src="<?php echo e(asset('adminFrontend/assets/js/bundle.js?ver=3.1.1')); ?>"></script>
    <script src="<?php echo e(asset('adminFrontend/assets/js/scripts.js?ver=3.1.1')); ?>"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"> </script>

<script>
    <?php if(Session::has('message')): ?>
    var type = "<?php echo e(Session::get('alert-type','info')); ?>"
    switch(type){
        case 'info':
            toastr.info(" <?php echo e(Session::get('message')); ?> ");
        break;
        case 'success':
            toastr.success(" <?php echo e(Session::get('message')); ?> ");
        break;
        case 'warning':
            toastr.warning(" <?php echo e(Session::get('message')); ?> ");
        break;
        case 'error':
            toastr.error(" <?php echo e(Session::get('message')); ?> ");
        break;
    }
    <?php endif; ?>
</script>



</html><?php /**PATH C:\Users\Public\Laravel\Laravel Breeze\laravel 9 Multi Auth\multyAuth\resources\views/masterAdmin.blade.php ENDPATH**/ ?>