<!DOCTYPE html>
<html>
<head>
<style>
/* table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
} */
table {
  border-collapse: collapse;
  border-spacing: 0;
  width: 100%;
  border: 1px solid #ddd;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}

th, td {
  text-align: left;
  padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}
</style>
</head>
<body>

<div>
    <a href="<?php echo e(route('admin.dashboard')); ?>"> Dashboard</a>
</div>

<h2>HTML Table</h2>

<div style="overflow-x:auto;">
<table>
  <tr>
    <th>Id</th>
    <th>Name</th>
    <th>Phone</th>
    <th>Nid</th>
    <th>Gender</th>
    <th>Birth Date</th>
    <th>Blood Group</th>
    <th>City</th>
    <th>Vehicle</th>
    <th>Driving License</th>
    <th>City Name</th>
    <th>Category</th>
    <th>Number</th>
    <th>Ref Code</th>
    <th>Bkash TransactionID</th>
    <th>Status</th>
  </tr>

<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($item->id); ?></td>
        <td><?php echo e($item->name); ?></td>
        <td><?php echo e($item->phone); ?></td>
        <td><?php echo e($item->nid); ?></td>
        <td><?php echo e($item->gender); ?></td>
        <td><?php echo e($item->birthDate); ?></td>
        <td><?php echo e($item->bloodGroup); ?></td>
        <td><?php echo e($item->city); ?></td>
        <td><?php echo e($item->vehicle); ?></td>
        <td><?php echo e($item->drivingLicense); ?></td>
        <td><?php echo e($item->cityName); ?></td>
        <td><?php echo e($item->category); ?></td>
        <td><?php echo e($item->number); ?></td>
        <td><?php echo e($item->refCode); ?></td>
        <td><?php echo e($item->transactionId); ?></td>

        <?php if($item->status==1): ?>

        <td>
            <a href="<?php echo e(url('admin/view/status/0')); ?>/<?php echo e($item->id); ?>">
                <button type="button" class="btn btn-primary">Active</button>
            </a>
        </td>
        
        <?php elseif($item->status==0): ?>

        <td>
            <a href="<?php echo e(url('admin/view/status/1')); ?>/<?php echo e($item->id); ?>">
                <button type="button" class="btn btn-outline-primary">Deactive</button>
            </a>
        </td>

        <?php endif; ?>


    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>
</div>




</body>
</html>
<?php /**PATH C:\Users\Public\Laravel\Laravel Breeze\laravel 9 Multi Auth\multyAuth\resources\views/users_view.blade.php ENDPATH**/ ?>