
<?php $__env->startSection('adminViewcasesDetais'); ?>

<!-- content @s -->
<div class="nk-content ">
    <div class="container-fluid">
        <div class="nk-content-inner">
            <div class="nk-content-body">
                <div class="nk-block-head nk-block-head-sm">
                    <div class="nk-block-between g-3">
                        <div class="nk-block-head-content">
                            <h3 class="nk-block-title page-title">Case Details /</h3>
                            <div class="nk-block-des text-soft">
                                <ul class="list-inline">
                                    <?php
                                    $user = \App\Models\User::find($caseDetails->userId);
                                    ?>
                                    <li>User Name: <span class="text-base"><?php echo e($user->name); ?></span></li>
                                    <li>Case Submitted: <span class="text-base"><?php echo e($caseDetails->created_at); ?></span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="nk-block-head-content">
                            <a href="" class="btn btn-outline-light bg-white d-none d-sm-inline-flex"><em
                                    class="icon ni ni-arrow-left"></em><span>Back</span></a>
                            <a href="<?php echo e(route('generatePdf',$caseDetails->id)); ?>" class="btn btn-outline-light bg-white d-none d-sm-inline-flex"><span>Download</span><em
                                    class="icon ni ni-arrow-down"></em></a>
                           
                        </div>
                    </div>
                </div><!-- .nk-block-head -->
                <div class="nk-block">
                    <div class="card card-bordered">
                        <div class="card-aside-wrap">
                            <div class="card-content">
                                <ul class="nav nav-tabs nav-tabs-mb-icon nav-tabs-card">
                                    <li class="nav-item">
                                        <a class="nav-link active" href="#"><em
                                                class="icon ni ni-user-circle"></em><span>Personal</span></a>
                                    </li>
                                    <!-- <li class="nav-item">
                                                        <a class="nav-link" href="#"><em class="icon ni ni-repeat"></em><span>Transactions</span></a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" href="#"><em class="icon ni ni-file-text"></em><span>Documents</span></a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" href="#"><em class="icon ni ni-bell"></em><span>Notifications</span></a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" href="#"><em class="icon ni ni-activity"></em><span>Activities</span></a>
                                                    </li> -->
                                    <li class="nav-item nav-item-trigger d-xxl-none">
                                        <a href="#" class="toggle btn btn-icon btn-trigger" data-target="userAside"><em
                                                class="icon ni ni-user-list-fill"></em></a>
                                    </li>
                                </ul><!-- .nav-tabs -->
                                <div class="card-inner">
                                    <div class="nk-block">
                                        <div class="nk-block-head">
                                            <h5 class="title">Case Information</h5>

                                        </div><!-- .nk-block-head -->
                                        <div class="profile-ud-list">
                                            <div class="profile-ud-item">
                                                <div class="profile-ud wider">



                                                    <span class="profile-ud-label">Case Number</span>


                                                    <span class="profile-ud-value"><?php echo e($caseDetails->caseId); ?></span>
                                                </div>
                                            </div>
                                            <div class="profile-ud-item">
                                                <div class="profile-ud wider">
                                                    <span class="profile-ud-label">Case Fine</span>
                                                    <span class="profile-ud-value"><?php echo e($caseDetails->caseCode); ?></span>
                                                </div>
                                            </div>
                                            <div class="profile-ud-item">
                                                <div class="profile-ud wider">
                                                    <span class="profile-ud-label">Comments</span>
                                                    <span class="profile-ud-value"><?php echo e($caseDetails->fineAmmount); ?>

                                                    </span>
                                                </div>
                                            </div>
                                            <div class="profile-ud-item">
                                                <div class="profile-ud wider">
                                                    <span class="profile-ud-label">Invoice </span>
                                                   <a href="<?php echo e(route('downloadInvoiceAdmin',$caseDetails->id)); ?>" class="btn btn-info">Download</a>
                                                </div>
                                            </div>
                                            <div class="profile-ud-item">
                                                <form method="POST" action="<?php echo e(route('adminUpdateCaseStatus',$caseDetails->id)); ?>">
                                                    <?php echo csrf_field(); ?>

                                                    <div class="profile-ud wider">
                                                        <span class="profile-ud-label">Status</span>
                                                        
                                                        <select name="caseStatus" id="caseStatus" class="form-control">
                                                        <option data-display="Select"><?php echo "$caseDetails->caseStatus" ?></option>
                                                            <option value="Pending">Pending</option>
                                                            <option value="Paid">Paid</option>
                                                            <option value="Approved">Approved</option>
                                                            <option value="Working">Working</option>
                                                            <option value="Done">Done</option>
                                                        </select>
                                                        
                                                        <button class="btn btn-info" type="submit">Save</button>
                                                    </div>
                                                </form>
                                            </div>
                                            <div class="profile-ud-item">
                                                <div class="profile-ud wider">
                                                    <span class="profile-ud-label">Case Photo</span>
                                                    <a download="custom-filename.jpg" href="<?php echo e(asset("$caseDetails->casePhoto")); ?>">
                                                        <img src="<?php echo e((!empty($caseDetails->casePhoto))? url($caseDetails->casePhoto):url('upload/no_image.jpg')); ?>" width="140" height="150">
                                                    </a>
                                                    </span>
                                                </div>
                                            </div>

                                        </div><!-- .profile-ud-list -->
                                    </div><!-- .nk-block -->
                                    <div class="nk-divider divider md"></div>
                                    <div class="nk-block">

                                        <div class="bq-note">
                                            <div class="bq-note-item">

                                                <!-- form start -->
                                                <!--================chat box start================-->
                                                <div class="myaccount-content">
                                                        <div class="panel">
                                                            <!--Heading-->
                                                            <div class="panel-heading">

                                                                <h3 class="panel-title">Chat</h3>
                                                            </div>

                                                            <!--Widget body-->
                                                            <div id="demo-chat-body" class="in">
                                                                <div class="nano has-scrollbar" style="height:380px">
                                                                    <div class="nano-content pad-all" tabindex="0"
                                                                        style="right: -17px;">
                                                                        <ul class="list-unstyled media-block">

                                                                            <?php $__currentLoopData = $usersCaseChat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chatInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                                            <li class="mar-btm">

                                                                                <?php if( $chatInfo->caseMsgSender == "a" ): ?>
                                                                            
                                                                                <div class="media-right">
                                                                                        <img src="https://bootdey.com/img/Content/avatar/avatar2.png"
                                                                                            class="img-circle img-sm"
                                                                                            alt="Profile Picture">
                                                                                    </div>
                                                                                    <div
                                                                                        class="media-body pad-hor speech-right">
                                                                                    <?php else: ?>
                                                                                    <div class="media-left">
                                                                                    <img src="https://bootdey.com/img/Content/avatar/avatar1.png"
                                                                                        class="img-circle img-sm"
                                                                                        alt="Profile Picture">
                                                                                </div>
                                                                                <div class="media-body pad-hor">
                                                                                        <?php endif; ?>


                                                                                        <div class="speech">
                                                                                           
                                                                                            <p><?php echo e($chatInfo->caseMsgText); ?>

                                                                                            </p>
                                                                                            <p class="speech-time">
                                                                                                <i
                                                                                                    class="fa fa-clock-o fa-fw"></i>
                                                                                                <?php echo e($chatInfo->created_at); ?>

                                                                                            </p>
                                                                                        </div>
                                                                                    </div>
                                                                            </li>


                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        </ul>
                                                                    </div>
                                                                    <div class="nano-pane">
                                                                        <div class="nano-slider"
                                                                            style="height: 141px; transform: translate(0px, 0px);">
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                <!--Widget footer-->
                                                                <div class="panel-footer">
                                                                    <div class="row">
                                                                        <form class="col-lg-12 mb-3" method="POST" action="<?php echo e(route('adminCaseMsgPost',$caseDetails->id)); ?>">

                                                                        <?php echo csrf_field(); ?>
                                                                        
                                                                        <div class="col-lg-12 mb-3">
                                                                        <textarea oninput="auto_grow(this)" name="caseMsgText"
                                                                                id="caseMsgText" rows="1" class="form-control"
                                                                                placeholder="message"></textarea>
                                                                        </div>

                                                                        <div class="col-lg-4 mx-auto mb-3">
                                                                            <button class="btn btn-primary btn-block"
                                                                                type="submit">Send</button>
                                                                        </div>
                                                                        </form>
                                                                        
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                <!--================chat box start================-->
                                                <!-- form end  -->
                                            </div><!-- .bq-note-item -->

                                            <!-- Button trigger modal -->


                                        </div><!-- .bq-note -->
                                    </div><!-- .nk-block -->
                                </div><!-- .card-inner -->
                            </div><!-- .card-content -->
                            <div class="card-aside card-aside-right user-aside toggle-slide toggle-slide-right toggle-break-xxl"
                                data-content="userAside" data-toggle-screen="xxl" data-toggle-overlay="true"
                                data-toggle-body="true">
                                <div class="card-inner-group" data-simplebar>
                                    <div class="card-inner">
                                        <div class="user-card user-card-s2">
                                            <div class="user-avatar lg bg-primary">
                                                <span>AB</span>
                                            </div>
                                            <div class="user-info">

                                                <h5>Name: <?php echo e($user->name); ?></h5>
                                                <span class="sub-text">Referance Number:
                                                    <?php echo e($user->shareableRefcode); ?></span>
                                            </div>
                                        </div>
                                    </div><!-- .card-inner -->





                                </div><!-- .card-inner -->
                            </div><!-- .card-aside -->
                        </div><!-- .card-aside-wrap -->
                    </div><!-- .card -->
                </div><!-- .nk-block -->
            </div>
        </div>
    </div>
</div>
<!-- content @e -->



<?php $__env->stopSection(); ?>









<!-- case image -->
<!-- <img src="<?php echo e((!empty($caseDetails->casePhoto))? url($caseDetails->casePhoto):url('upload/no_image.jpg')); ?>" width="140" height="150"> -->
<?php echo $__env->make('masterAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Public\Laravel\Laravel Breeze\laravel 9 Multi Auth\multyAuth\resources\views/case_details.blade.php ENDPATH**/ ?>