<!DOCTYPE html>
<html lang="zxx" class="js">

<head>
    <base href="./">
    <meta charset="utf-8">
    <meta name="author" content="Softnio">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="A powerful and conceptual apps base dashboard template that especially build for developers and programmers.">
    <!-- Fav Icon  -->
    <link rel="shortcut icon" href="<?php echo e(asset('adminFrontend/images/favicon.png')); ?>">
    <!-- Page Title  -->
    <title>DashLite Template</title>
    <!-- StyleSheets  -->
    <link rel="stylesheet" href="<?php echo e(asset('adminFrontend/assets/css/dashlite.css?ver=3.1.1')); ?>">
    <link id="skin-default" rel="stylesheet" href="<?php echo e(asset('adminFrontend/assets/css/theme.css?ver=3.1.1')); ?>">
</head>

<?php echo $__env->make('user.userNavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('userDashboard'); ?>
    

<?php echo $__env->make('user.userFooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!-- JavaScript -->
    <script src="<?php echo e(asset('adminFrontend/assets/js/bundle.js?ver=3.1.1')); ?>"></script>
    <script src="<?php echo e(asset('adminFrontend/assets/js/scripts.js?ver=3.1.1')); ?>"></script>


</html><?php /**PATH C:\Users\Public\Laravel\Laravel Breeze\laravel 9 Multi Auth\multyAuth\resources\views/masterUser.blade.php ENDPATH**/ ?>